import sys

sys.path.insert(0, '.')

import mud
reload(mud)